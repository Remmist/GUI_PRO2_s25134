package Game;


import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;

import javafx.scene.Scene;

import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;

import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;



public class BoardController {

    private static Card actual = null;
    private static int score = 0;
    private static int clickCount = 2;
    private static int pairs = (BoardSettingsController.Columns * BoardSettingsController.Rows) / 2;
    private static int pairsLeft = pairs;

    @FXML
    static

    Text appTime;

    @FXML
    BorderPane boardWindow;

    @FXML
    Pane gameBoard;

    public static int getClickCount() {
        return clickCount;
    }

    public static void setClickCount(int clickCount) {
        BoardController.clickCount = clickCount;
    }

    public static Card getActual() {
        return actual;
    }

    public static void setActual(Card actual) {
        BoardController.actual = actual;
    }

    public static int getPairsLeft() {
        return pairsLeft;
    }

    public static void setPairsLeft(int pairsLeft) {
        BoardController.pairsLeft = pairsLeft;
    }

    public static int getScore() {
        return score;
    }

    public void initialize() throws FileNotFoundException {
        score = BoardSettingsController.Rows * BoardSettingsController.Columns;

        boardWindow.setPrefHeight(BoardSettingsController.Rows * 150);
        boardWindow.setPrefWidth(BoardSettingsController.Columns * 100);

        ArrayList<Card> cards = new ArrayList<>();
        for (int i = 0; i < pairs; i++) {
            cards.add(new Card("D:\\GUI_PRO2_s25134\\src\\Game\\images\\p" + (i + 1) + ".jpeg", i));
            cards.add(new Card("D:\\GUI_PRO2_s25134\\src\\Game\\images\\p" + (i + 1) + ".jpeg", i));
        }

        Collections.shuffle(cards);

        for (int i = 0; i < cards.size(); i++) {
            Card card = cards.get(i);
            card.setTranslateX(100 * (i % BoardSettingsController.Rows));
            card.setTranslateY(100 * (i / BoardSettingsController.Rows));
            gameBoard.getChildren().add(card);
        }
    }

    public static void endGame() throws IOException {
        Scene menuScene = appTime.getScene();
        Stage window = (Stage) menuScene.getWindow();
        FXMLLoader loader = new FXMLLoader(BoardController.class.getResource("scenes/saveScore.fxml"));
        menuScene = new Scene(loader.load());
        window.setScene(menuScene);
        window.setWidth(600);
        window.setHeight(400);




//        FXMLLoader loader = new FXMLLoader(BoardController.class.getResource("scenes/saveScore.fxml"));
//        Scene menuScene = new Scene(loader.load());
//        Stage window = (Stage) menuScene.getWindow();
//        window.setScene(menuScene);
//        window.setWidth(600);
//        window.setHeight(400);




    }

    public void exitApp() {
        Stage stage = (Stage) appTime.getScene().getWindow();
        stage.close();
    }

    public void exitWithKey(KeyEvent key) {
        KeyCombination exitCombination = new KeyCodeCombination(KeyCode.Q, KeyCombination.CONTROL_DOWN, KeyCombination.ALT_DOWN);
        if (exitCombination.match(key)) {
            Stage stage = (Stage) gameBoard.getScene().getWindow();
            stage.close();
            System.out.println("CTRL + ALT");
        }
    }
}