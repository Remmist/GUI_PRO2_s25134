package Game;

import javafx.animation.FadeTransition;
import javafx.geometry.Pos;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Card extends StackPane {
    private ImageView cardImageView;
    private int cardID;

    public Card(String path, int cardID) throws FileNotFoundException {
        Image cardImage = new Image(new FileInputStream(path));
        cardImageView = new ImageView(cardImage);
        cardImageView.setFitHeight(100);
        cardImageView.setFitWidth(100);
        cardImageView.setPreserveRatio(true);
        this.cardID = cardID;
        Rectangle border = new Rectangle(100, 100);
        border.setFill(null);
        border.setStroke(Color.GREEN);
        border.setStrokeWidth(2);

        setAlignment(Pos.CENTER);
        getChildren().addAll(cardImageView, border);
        setOnMouseClicked(event -> {
            if (isOpen() || BoardController.getClickCount() == 0)
                return;

            BoardController.setClickCount(BoardController.getClickCount() - 1);

            //открыть первую карту
            if (BoardController.getActual() == null) {
                BoardController.setActual(this);
                open(() -> {});
                return;
            }
            open(() -> {
                if(CardsAreEqual(BoardController.getActual()))
                    BoardController.setPairsLeft(BoardController.getPairsLeft() - 1);
                else {
                    BoardController.getActual().close();
                    this.close();
                }

                if (BoardController.getPairsLeft() == 0) {
                    try {
                        BoardController.endGame();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    return;
                }
                BoardController.setActual(null);
                BoardController.setClickCount(2);
            });
        });
        close();
    }

    public boolean isOpen() {
        return cardImageView.getOpacity() == 1;
    }

    public void open(Runnable action) {
        FadeTransition ft = new FadeTransition(Duration.seconds(0.5), cardImageView);
        ft.setToValue(1);
        ft.setOnFinished(e -> action.run());
        ft.play();
    }

    public void close() {
        FadeTransition ft = new FadeTransition(Duration.seconds(0.5), cardImageView);
        ft.setToValue(0);
        ft.play();
    }

    public boolean CardsAreEqual(Card other) {
        return cardID == other.cardID;
    }
}
